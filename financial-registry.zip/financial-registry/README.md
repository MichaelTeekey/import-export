# financial-registry

if you intend to use docker install docker then run "docker-compose up --build -d" this will install packages for docker

#folder structure
        src ==========> contains laravel project files
        .docker ======> contains docker config files 
        
#DB setup (docker only)
    use this <a href="https://github.com/Nyamwena/docker-db">Docker dDB</a>

  
