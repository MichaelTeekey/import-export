@extends('layouts.main')

@section('content')

<!DOCTYPE html>
<html>
<head>
    <title>Import Customers</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<br />









<div class="container">
    <h3 align="center">Import Customers</h3>
    <br />
    @if(count($errors) > 0)
        <div class="alert alert-danger">
            Upload Validation Error<br><br>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if($message = Session::get('success'))
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>{{ $message }}</strong>
        </div>
    @endif
    <form  action="{{route('import_excel.upload')}}" method="post" enctype="multipart/form-data" >
        {{ csrf_field() }}
        <div class="form-group">
            <table class="table">
                <tr>
                    <td width="40%" align="right"><label>Select File for Upload</label></td>
                    <td width="30">
                        <input type="file" name="select_file" />
                    </td>
                    <td width="30%" align="left">
                        <input type="submit" name="upload" class="btn btn-primary" value="Upload">
                    </td>
                </tr>
                <tr>
                    <td width="40%" align="right"></td>
                    <td width="30"><span class="text-muted">.xls, .xslx</span></td>
                    <td width="30%" align="left"></td>
                </tr>
            </table>
        </div>
    </form>

    <br />
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Customer Data</h3>
        </div>
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <tr>
                        <th>Customer Number</th>
                        <th>Customer Account</th>
                        <th>Address</th>
                        <th>Mailing Address</th>
                        <th>City</th>
                        <th>Email</th>
                        <th>Mobile number</th>
                        <th>Telephone</th>
                        <th>Credit Plan</th>
                        <th>Active</th>
                    </tr>
                    @foreach($data as $row)
                        <tr>
                            <td>{{ $row->fl_consumer_number }}</td>
                            <td>{{ $row->fl_consumer_account }}</td>
                            <td>{{ $row->fl_physical_address }}</td>
                            <td>{{ $row->fl_mailing_address}}</td>
                            <td>{{ $row->fl_city }}</td>
                            <td>{{ $row->fl_email }}</td>
                            <td>{{ $row->fl_mobile_number }}</td>
                            <td>{{ $row->fl_telephone }}</td>
                            <td>{{ $row->fl_credit_plan }}</td>
                            <td>{{ $row->fl_active }}</td>
                        </tr>
                    @endforeach
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>

  @include('sweetalert::alert')
@endsection






{{--<div class="grid grid-cols-12 gap-6 mt-5">--}}
{{--    <div class="intro-y col-span-12 lg:col-span-12">--}}
{{--        <!-- BEGIN: Form Layout -->--}}

{{--        <div class="intro-y box p-8">--}}
{{--            <form action="{{route('import_excel.upload')}}" method="post">--}}
{{--                @csrf--}}
{{--                <div class="">--}}
{{--                    <div class="grid grid-cols-12 gap-4 row-gap-5 mt-5">--}}

{{--                        <div class="intro-y col-span-12 sm:col-span-5">--}}
{{--                            <div class="mb-2">Account Number</div>--}}
{{--                            <input type="text" class="input w-full border flex-1" name="fl_account_num"  required>--}}
{{--                            @error('fl_account_num')--}}
{{--                            <div class="mb-2 text-red-500"> {{$message}}</div>--}}
{{--                            @enderror--}}

{{--                        </div>--}}
{{--                        <div class="intro-y col-span-12 sm:col-span-5">--}}
{{--                            <div class="mb-2">Account Name</div>--}}
{{--                            <input type="text" class="input w-full border flex-1" placeholder=" " name="fl_account_name"  required>--}}
{{--                            @error('fl_account_name')--}}
{{--                            <div class="mb-2 text-red-500"> {{$message}}</div>--}}
{{--                            @enderror--}}
{{--                        </div>--}}
{{--                        <div class="intro-y col-span-12 sm:col-span-2">--}}
{{--                            <div class="mb-2">Account Main Type</div>--}}
{{--                            <select name="fl_account_main_type" data-placeholder="Select Account Type" class="select2 w-full" id="" required>--}}
{{--                                <option value="">----pick an option--- </option>--}}
{{--                                @foreach($account_main as $type)--}}
{{--                                    <option value="{{$type->id}}">{{$type->fl_account_type}}</option>--}}
{{--                                @endforeach--}}

{{--                            </select>--}}
{{--                            @error('fl_account_main_type')--}}
{{--                            <div class="mb-2 text-red-500"> {{$message}}</div>--}}
{{--                            @enderror--}}

{{--                        </div>--}}

{{--                        <div class="intro-y col-span-12 sm:col-span-4">--}}
{{--                            <div class="mb-2">Account Subtype-A</div>--}}
{{--                            <select name="fl_account_sub_type_a" data-placeholder="Select Account Type" class="select2 w-full" id="" required>--}}
{{--                                <option value="">----pick an option--- </option>--}}
{{--                                @foreach($account_type as $type)--}}
{{--                                    <option value="{{$type->fl_acc_type_code}}">{{$type->fl_account_type_name}}</option>--}}
{{--                                @endforeach--}}
{{--                            </select>--}}
{{--                            @error('fl_account_sub_type_a')--}}
{{--                            <div class="mb-2 text-red-500"> {{$message}}</div>--}}
{{--                            @enderror--}}

{{--                        </div>--}}

{{--                        <div class="intro-y col-span-12 sm:col-span-4">--}}
{{--                            <div class="mb-2">Account Subtype-B</div>--}}
{{--                            <select name="fl_account_sub_type_b" data-placeholder="Select Account Type" class="select2 w-full" id="" required>--}}
{{--                                <option value="">----pick an option--- </option>--}}
{{--                                @foreach($account_type as $type)--}}
{{--                                    <option value="{{$type->fl_acc_type_code}}">{{$type->fl_account_type_name}}</option>--}}
{{--                                @endforeach--}}
{{--                            </select>--}}

{{--                            @error('fl_account_sub_type_b')--}}
{{--                            <div class="mb-2 text-red-50"> {{$message}}</div>--}}
{{--                            @enderror--}}

{{--                        </div>--}}

{{--                        <div class="intro-y col-span-12 sm:col-span-4">--}}
{{--                            <div class="mb-2">Is It Bank?</div>--}}
{{--                            <select name="fl_account_bank" class="input w-full border flex-1"  id="" required>--}}
{{--                                <option value="1">Yes</option>--}}
{{--                                <option value="0">No</option>--}}
{{--                            </select>--}}
{{--                            @error('fl_account_bank')--}}
{{--                            <div class="mb-2 text-red-50"> {{$message}}</div>--}}
{{--                            @enderror--}}

{{--                        </div>--}}


{{--                        <div class="intro-y col-span-12 flex items-center justify-center sm:justify-end mt-5">--}}
{{--                            <button type="reset" class="button w-24 justify-center block bg-red-200 text-gray-600">Reset</button>--}}
{{--                            <button type="submit" class="button w-24 justify-center block bg-theme-1 text-white ml-2">Save</button>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </form>--}}
{{--        </div>--}}
{{--        <!-- END: Form Layout -->--}}
{{--    </div>--}}
{{--</div>--}}


