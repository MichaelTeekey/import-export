<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
    protected $table = 'tbl_consumer';
    protected $fillable = [
        'fl_consumer_number',
        'fl_consumer_account',
        'fl_physical_address',
        'fl_mailing_address',
        'fl_city',
        'fl_email',
        'fl_mobile_number',
        'fl_telephone',
        'fl_credit_plan',
        'fl_active',

    ];
}
