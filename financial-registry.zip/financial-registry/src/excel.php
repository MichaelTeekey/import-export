<?php
//database connection
$connect = mysqli_connect("localhost","root","","mucho" );

$output ='';
if (isset($_POST['export_excel']))
{
    $sql = "SELECT * FROM tbl_consumer ORDER BY id DESC ";
    $result = mysqli_query($connect, $sql);
    if(mysqli_num_rows($result)>0)

    {
        $output .= '
            <table class ="table" bordered="1">
            <tr>
                <th>consumer number</th>
                <th>consumer account</th>
                <th>physical address</th>
                <th>mailing address</th>
                <th>city</th>
                <th>email</th>
                <th>mobile number</th>
                <th>Telephone</th>
                <th>Credit plan</th>
                <th>Active</th>


            </tr>


        ';
        while ($row = mysqli_fetch_array($result))
        {
            $output .= '
                <tr>
                    <td>'.$row["consumer number"].'</td>
                    <td>'.$row["consumer account"].'</td>
                    <td>'.$row["physical address"].'</td>
                    <td>'.$row["mailing address"].'</td>
                    <td>'.$row["city"].'</td>
                    <td>'.$row["email"].'</td>
                    <td>'.$row["mobile number"].'</td>
                    <td>'.$row["Telephone number"].'</td>
                    <td>'.$row["Credit plan"].'</td>
                    <td>'.$row["Active"].'</td>

                </tr>
            ';
        }
        $output="</table>";
        header("Content-Type: application/xls");
        header("Content-Disposition: attachment, filename=download.xls");
        echo $output;
    }

}
?>

//namespace excel;
//use Illuminate\Request;
//use DB;
//
//
//class ImportExcelController extends Controller
//{
//    function index()
//    {
//        $data = DB::table('tbl_consumer')->orderBy('fl_consumer_number', 'DESC')
//            ->get();
//        return view('import_excel', compact('data'));
//    }
//    function import(Request $request)
//    {
//        $this->validate($request, [
//            'select_file'  => 'required|mimes:xls,xlsx'
//        ]);
//
//        $path = $request->file('select_file')->getRealPath();
//
//        $data = Excel::load($path)->get();
//
//        if($data->count() > 0)
//        {
//            foreach($data->toArray() as $key => $value)
//            {
//                foreach($value as $row)
//                {
//                    $insert_data[] = array(
//                        'Cunsumer Number'  => $row['fl_consumer_number'],
//                        'Consumer account'   => $row['fl_consumer_account'],
//                        'Address'   => $row['fl_physical_address'],
//                        'Mailing Address'    => $row['fl_mailing_address'],
//                        'City'  => $row['fl_city'],
//                        'Email'   => $row['fl_email'],
//                        'Mobile number'   => $row['fl_mobile_number'],
//                        'Telephone'   => $row['fl_telephone'],
//                        'Credit plan'   => $row['fl_credit_plan'],
//                        'Active'   => $row['fl_active']
//
//                    );
//                }
//            }
//
//            if(!empty($insert_data))
//            {
//                DB::table('tbl_consumer')->insert($insert_data);
//            }
//        }
//        return back()->with('success', 'Excel Data Imported successfully.');
//    }
//
//
//}

?>

